import Header from './Components/Header';

function App() {
    return (
        <div className="container">
            <Header title="tarefas" />
        </div>
    );
}

export default App;
